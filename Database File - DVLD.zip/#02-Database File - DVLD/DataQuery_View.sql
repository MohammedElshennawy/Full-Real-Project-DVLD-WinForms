
--Local Driving App View
SELECT ldlap.LocalDrivingLicenseApplicationID, lc.ClassName, pep.NationalNo, 
	   FullName = pep.FirstName + ' ' + pep.SecondName + ' ' + ISNULL(pep.ThirdName + ' ', '') + pep.LastName, app.ApplicationDate,

		(SELECT COUNT (tsa.TestTypeID) As PassedTestCount
		 FROM TestAppointments As tsa
		 INNER JOIN Tests As ts
		 ON ts.TestAppointmentID = tsa.TestAppointmentID
		 WHERE (tsa.LocalDrivingLicenseApplicationID = ldlap.LocalDrivingLicenseApplicationID) AND (ts.TestResult = 1)
		 ) As PassedTestCount,

		CASE WHEN app.ApplicationStatus = 1 THEN 'New'
             WHEN app.ApplicationStatus = 2 THEN 'Cancelled'
			 ELSE 'Completed'
		END As Status

FROM LocalDrivingLicenseApplications As ldlap
INNER JOIN Applications As app
ON ldlap.ApplicationID = app.ApplicationID
INNER JOIN LicenseClasses As lc
ON ldlap.LicenseClassID = lc.LicenseClassID
INNER JOIN People As pep
ON app.ApplicantPersonID = pep.PersonID

----------------------------------------------------------------------------------------------------------

--Test Appointment View.
SELECT tap.TestAppointmentID, tap.LocalDrivingLicenseApplicationID, ttp.TestTypeTitle, lc.ClassName, tap.AppointmentDate, tap.PaidFees,
	   FullName = pe.FirstName + ' ' + pe.SecondName + ' ' + ISNULL(pe.ThirdName + ' ', '') + pe.LastName, tap.IsLocked
FROM TestAppointments As tap
INNER JOIN TestTypes As ttp
ON tap.TestTypeID = ttp.TestTypeID
INNER JOIN LocalDrivingLicenseApplications As ldlap
ON tap.LocalDrivingLicenseApplicationID = ldlap.LocalDrivingLicenseApplicationID
INNER JOIN LicenseClasses As lc
ON ldlap.LicenseClassID = lc.LicenseClassID
INNER JOIN Applications As ap
ON ldlap.ApplicationID = ap.ApplicationID
INNER JOIN People As pe
ON ap.ApplicantPersonID = pe.PersonID

----------------------------------------------------------------------------------------------------------

--Drivers View.
SELECT dr.DriverID, dr.PersonID, pe.NationalNo, FullName = pe.FirstName + ' ' + pe.SecondName + ' ' + ISNULL(pe.ThirdName + ' ', '') + pe.LastName,
	   dr.CreatedDate, (SELECT COUNT(LicenseID) As NumberOfActiveLicenses
						FROM Licenses
						WHERE IsActive = 1 AND DriverID = dr.DriverID) As NumberOfActiveLicenses
FROM Drivers As dr
INNER JOIN People As pe
ON dr.PersonID = pe.PersonID
