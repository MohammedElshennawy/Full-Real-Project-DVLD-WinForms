--Create New DataBase if not Exists
--========================================--
IF NOT EXISTS (SELECT *
			   FROM sys.databases
			   WHERE NAME = 'DVLD2')

BEGIN
	CREATE DATABASE DVLD2;
END

---------------------------------------------------------------------
USE DVLD2;

--Create Table of Countries
--========================================--
CREATE TABLE Countries(
						CountryID INT IDENTITY(1,1) NOT NULL,
						CountryName NVARCHAR(50) NOT NULL,
						PRIMARY KEY (CountryID)
						);

--Create Table of People
--========================================--
CREATE TABLE People(
					PersonID INT IDENTITY(1,1) NOT NULL, --To specify that the "PersonID" column should start at value 1 and increment by 1.
					NationalNo NVARCHAR(20) NOT NULL,
					FirstName NVARCHAR(20) NOT NULL,
					SecondName NVARCHAR(20) NOT NULL,
					ThirdName NVARCHAR(20) NULL,
					LastName NVARCHAR(20) NOT NULL,
					DateOFBirth DATETIME NOT NULL,
					Gender TINYINT NOT NULL,
					Address NVARCHAR(500) NOT NULL,
					Phone NVARCHAR(20) NOT NULL,
					Email NVARCHAR(50) NULL,
					NationalityCountryID INT NOT NULL REFERENCES Countries(CountryID),
					ImagePath NVARCHAR(250) NULL,
					PRIMARY KEY (PersonID)
					);

--Add Description to Gender Column.
EXEC sys.sp_addextendedproperty 
	@name=N'MS_Description', 
	@value=N'0 Male , 1 Female' , 
	@level0type=N'SCHEMA',
	@level0name=N'dbo', 
	@level1type=N'TABLE',
	@level1name=N'People', 
	@level2type=N'COLUMN',
	@level2name=N'Gender'
GO


--Create Table of Users
--========================================--
CREATE TABLE Users(
					UserID INT IDENTITY(1,1) NOT NULL,
					PersonID INT NOT NULL REFERENCES People(PersonID),
					UserName NVARCHAR(20) NOT NULL,
					Password NVARCHAR(20) NOT NULL,
					IsActive BIT NOT NULL,
					PRIMARY KEY (UserID)
					);


--Create Table of Application Types
--========================================--
CREATE TABLE ApplicationTypes(
								ApplicationTypeID INT IDENTITY(1,1) NOT NULL,
								ApplicationTypeTitle NVARCHAR(150) NOT NULL,
								ApplicationFees SMALLMONEY NOT NULL,
								PRIMARY KEY (ApplicationTypeID)
								);


--Create Table of Applications
--========================================--
CREATE TABLE Applications(
							ApplicationID INT IDENTITY(1,1) NOT NULL,
							ApplicationPersonID INT NOT NULL REFERENCES People(PersonID),
							ApplicationDate DATETIME NOT NULL,
							ApplicationTypeID INT NOT NULL REFERENCES ApplicationTypes(ApplicationTypeID),
							ApplicationStatus TINYINT NOT NULL,
							LastStatusDate DATETIME NOT NULL,
							PaidFees SMALLMONEY NOT NULL,
							CreatedByUserID INT NOT NULL REFERENCES Users(UserID),
							PRIMARY KEY (ApplicationID)
							);

--Add Description to ApplicationStatus Column.
EXEC sys.sp_addextendedproperty 
	@name=N'MS_Description', 
	@value=N'1-New 2-Cancelled 3-Completed', 
	@level0type=N'SCHEMA',
	@level0name=N'dbo', 
	@level1type=N'TABLE',
	@level1name=N'Applications', 
	@level2type=N'COLUMN',
	@level2name=N'ApplicationStatus'
GO


--Create Table of License Classes
--========================================--
CREATE TABLE LicenseClasses(
							LicenseClassID INT IDENTITY(1,1) NOT NULL,
							ClassName NVARCHAR(50) NOT NULL,
							ClassDescription NVARCHAR(500) NOT NULL,
							MinimumAllowedAge TINYINT NOT NULL,
							DefaultValidityLength TINYINT NOT NULL,
							ClassFees SMALLMONEY NOT NULL,
							PRIMARY KEY (LicenseClassID)
							);

--Add Descriptions to MinimumAllowedAge and DefaultValidityLength Columns.
EXEC sys.sp_addextendedproperty 
	@name=N'MS_Description', 
	@value=N'Minmum age allowed to apply for this license', 
	@level0type=N'SCHEMA',
	@level0name=N'dbo', 
	@level1type=N'TABLE',
	@level1name=N'LicenseClasses', 
	@level2type=N'COLUMN',
	@level2name=N'MinimumAllowedAge'

EXEC sys.sp_addextendedproperty
	@name=N'MS_Description', 
	@value=N'How many years the licesnse will be valid.', 
	@level0type=N'SCHEMA',
	@level0name=N'dbo', 
	@level1type=N'TABLE',
	@level1name=N'LicenseClasses', 
	@level2type=N'COLUMN',
	@level2name=N'DefaultValidityLength'
GO


--Create Table of Local Driving License Applications
--===================================================--
CREATE TABLE LocalDrivingLicenseApplications(
											LocalDrivingLicenseApplicationID INT IDENTITY(1,1) NOT NULL,
											ApplicationID INT NOT NULL REFERENCES Applications(ApplicationID),
											LicenseClassID INT NOT NULL REFERENCES LicenseClasses(LicenseClassID)
											PRIMARY KEY (LocalDrivingLicenseApplicationID)
											);




--Create Table of Test Types
--=============================--
CREATE TABLE TestTypes(
						TestTypeID INT IDENTITY(1,1) NOT NULL,
						TestTypeTitle NVARCHAR(100) NOT NULL,
						TestTypeDescription NVARCHAR(500) NOT NULL,
						TestTypeFees SMALLMONEY NOT NULL,
						PRIMARY KEY (TestTypeID)
						);


--Create Table of Test Appiontments
--=====================================--
CREATE TABLE TestAppiontments(
								TestAppiontmentID INT IDENTITY(1,1) NOT NULL,
								TestTypeID INT NOT NULL REFERENCES TestTypes(TestTypeID),
								LocalDrivingLicenseApplicationID INT NOT NULL REFERENCES LocalDrivingLicenseApplications(LocalDrivingLicenseApplicationID),
								AppiontmentDate SMALLDATETIME NOT NULL,
								PaidFees SMALLMONEY NOT NULL,
								IsLocked BIT NOT NULL,
								RetakeTestApplicationID INT NULL REFERENCES Applications(ApplicationID),
								PRIMARY KEY (TestAppiontmentID)
								);


--Create Table of Tests
--========================--	
CREATE TABLE Tests(
					TestID INT IDENTITY(1,1) NOT NULL,
					TestAppiontmentID INT NOT NULL REFERENCES TestAppiontments(TestAppiontmentID),
					TestResult BIT NOT NULL,
					Notes VARCHAR(500) NULL,
					CreatedByUserID INT NOT NULL REFERENCES Users(UserID),
					PRIMARY KEY (TestID)
					);

--Add Descriptions to TestResult Column.
EXEC sys.sp_addextendedproperty 
	@name=N'MS_Description', 
	@value=N'0-Fail 1-Pass', 
	@level0type=N'SCHEMA',
	@level0name=N'dbo', 
	@level1type=N'TABLE',
	@level1name=N'Tests', 
	@level2type=N'COLUMN',
	@level2name=N'TestResult'
GO
	

--Create Table of Drivers
--============================--
CREATE TABLE Drivers(
					DriverID INT IDENTITY(1,1) NOT NULL,
					PersonID INT NOT NULL REFERENCES People(PersonID),
					CreatedByUserID INT NOT NULL REFERENCES Users(UserID),
					CreatedDate SMALLDATETIME NOT NULL
					PRIMARY KEY (DriverID)
					);


--Create Table of Licenses
--=============================--
CREATE TABLE Licenses(
						LicenseID INT IDENTITY(1,1) NOT NULL,
						ApplicationID INT NOT NULL REFERENCES Applications(ApplicationID),
						DriverID INT NOT NULL REFERENCES Drivers(DriverID),
						LicenseClassID INT NOT NULL REFERENCES LicenseClasses(LicenseClassID),
						IssueDate DATETIME NOT NULL,
						ExpirationDate DATETIME NOT NULL,
						Notes NVARCHAR(500) Null,
						PaidFees SMALLMONEY NOT NULL,
						IsActive BIT NOT NULL,
						IssueReason TINYINT NOT NULL,
						CreatedByUserID INT NOT NULL REFERENCES Users(UserID),
						PRIMARY KEY (LicenseID)
						);

--Add Descriptions to IssueReason Column.
EXEC sys.sp_addextendedproperty 
	@name=N'MS_Description', 
	@value=N'1-FirstTime, 2-Renew, 3-Replacement for Damaged, 4-Replacement for Lost.', 
	@level0type=N'SCHEMA',
	@level0name=N'dbo', 
	@level1type=N'TABLE',
	@level1name=N'Licenses', 
	@level2type=N'COLUMN',
	@level2name=N'IssueReason'
GO


--Create Table of Detained Licenses
--====================================--
CREATE TABLE DetainedLicenses(
								DetainID INT IDENTITY(1,1) NOT NULL,
								LicenseID INT NOT NULL REFERENCES Licenses(LicenseID),
								DetainDate SMALLDATETIME NOT NULL,
								FineFees SMALLMONEY NOT NULL,
								CreatedByUserID INT NOT NULL REFERENCES Users(UserID),
								IsReleased BIT NOT NULL,
								ReleaseDate SMALLDATETIME NULL,
								ReleasedByUserID INT NULL REFERENCES Users(UserID),
								ReleaseApplication INT NULL REFERENCES Applications(ApplicationID),
								PRIMARY KEY (DetainID)
								);



--Create Table of International Licenses
--===========================================--
CREATE TABLE InternationalLicenses(
									InternationalLicenseID INT IDENTITY(1,1) NOT NULL,
									ApplicationID INT NOT NULL REFERENCES Applications(ApplicationID),
									DriverID INT NOT NULL REFERENCES Drivers(DriverID),
									IssuedUsingLocalLicenseID INT NOT NULL REFERENCES Licenses(LicenseID),
									IssueDate SMALLDATETIME NOT NULL,
									ExpirationDate SMALLDATETIME NOT NULL,
									IsActive BIT NOT NULL,
									CreatedByUserID INT NOT NULL REFERENCES Users(UserID),
									PRIMARY KEY (InternationalLicenseID)
									);



